def classify_player(scores):
    star = scores["star_score"]
    consistency = scores["consistency_score"]

    if star > 0.75 and consistency > 0.60:
        return "OVER_POOL"

    if star < 0.35 and consistency < 0.50:
        return "UNDER_POOL"

    return "NEUTRAL"
