"""Compatibility namespace for MBM Core domain modules."""
