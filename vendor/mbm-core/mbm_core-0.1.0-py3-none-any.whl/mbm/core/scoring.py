import json
import math
from importlib.resources import files


def load_config():
    config_path = files("mbm.core").joinpath("sigmoid_config.json")
    with config_path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


config = load_config()


def sigmoid(x, x0, k):
    return 1 / (1 + math.exp(-k * (x - x0)))


def compute_scores(player):
    return {
        "star_score": sigmoid(
            player["kill_share"],
            config["star_power"]["x0"],
            config["star_power"]["k"],
        ),
        "consistency_score": sigmoid(
            player["stability"],
            config["consistency"]["x0"],
            config["consistency"]["k"],
        ),
        "eco_score": sigmoid(
            player["eco_dependency"],
            config["eco_fragility"]["x0"],
            config["eco_fragility"]["k"],
        ),
    }
