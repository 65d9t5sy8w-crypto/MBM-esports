"""MBM Core package namespace."""
